var initialize, preventDefault;

initialize = function() {
  $('.btn-user-guide').on('click', function(event) {
    preventDefault(event);
    return downloadUserGuide();
  });
  return $('.btn-get-started').on('click', function(event) {
    preventDefault(event);
    return start();
  });
};

preventDefault = function(event) {
  if (event.preventDefault) {
    event.preventDefault();
  } else {
    event.returnValue = false;
  }
  return event.doit = false;
};

initialize();
