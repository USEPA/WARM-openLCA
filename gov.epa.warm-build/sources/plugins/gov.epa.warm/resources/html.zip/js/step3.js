var initialize;

initialize = function(data) {
  setInputs(data);
  return recordInputs();
};
