var fillProductionTable, initializeProduction, setEquivalents, setProductionResults;

initializeProduction = function() {
  return $('.with-note').tooltip();
};

setProductionResults = function(materials, baselineTotal, alternativeTotal) {
  fillProductionTable(materials);
  $('.info-box #total-baseline').html(numeral(baselineTotal).format('0.00'));
  $('.info-box #total-alternative').html(numeral(alternativeTotal).format('0.00'));
  $('.info-box #total-change').html(numeral(alternativeTotal - baselineTotal).format('0.00'));
  $('.with-note').tooltip();
  return null;
};

fillProductionTable = function(materials) {
  var body, err, i, index, len, nextMaterial, result, results, results1, stack, type, unit;
  results = JSON.parse(materials);
  index = 1;
  stack = [];
  for (i = 0, len = results.length; i < len; i++) {
    result = results[i];
    stack.push(result);
  }
  body = $('body');
  type = body.attr('data-type');
  unit = body.attr('data-unit');
  results1 = [];
  while (stack.length !== 0) {
    nextMaterial = stack.pop();
    try {
      results1.push($('.result-table tbody').prepend(jade.templates['production-result-row']({
        material: nextMaterial,
        type: type,
        unit: unit,
        formatNumber: formatNumber
      })));
    } catch (error) {
      err = error;
      results1.push(document.getElementById("exception").innerHTML = err.message);
    }
  }
  return results1;
};

setEquivalents = function(equivalentsString) {
  var box, doShow, equivalents, i, id, len, ref, results1, value;
  equivalents = JSON.parse(equivalentsString);
  ref = Object.keys(equivalents);
  results1 = [];
  for (i = 0, len = ref.length; i < len; i++) {
    id = ref[i];
    value = equivalents[id];
    if (id.indexOf('annual') !== -1) {
      value = Math.abs(formatNumber(value, 5));
      doShow = parseInt(value * 100000) >= 1;
    } else {
      value = parseInt(Math.abs(value));
      doShow = value >= 1;
    }
    box = $("#" + id + ".equivalent");
    if (doShow) {
      box.removeClass('hidden');
      if (equivalents[id] >= 0) {
        $('.positive-prefix', box).removeClass('hidden');
        $('.negative-prefix', box).addClass('hidden');
      } else {
        $('.positive-prefix', box).addClass('hidden');
        $('.negative-prefix', box).removeClass('hidden');
      }
      results1.push($('.equivalent-value', box).html(value));
    } else {
      results1.push(box.addClass('hidden'));
    }
  }
  return results1;
};

initializeProduction();
