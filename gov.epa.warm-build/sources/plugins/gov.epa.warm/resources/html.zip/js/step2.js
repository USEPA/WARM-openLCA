var initListeners, initialize, initialized, updateAnaerobicDigestionStatus, updateLandfillStatus, updateStateStatus, updateTransportStatus;

initialized = false;

initialize = function(data) {
  var i, len, location, locations, ref, ref1, ref2;
  if (initialized) {
    return;
  }
  initialized = true;
  locations = Object.keys(regions);
  for (i = 0, len = locations.length; i < len; i++) {
    location = locations[i];
    $('#state').append('<option value="' + location + '">' + location + '</option>');
  }
  setInputs(data);
  updateTransportStatus((ref = inputs['transport_distance']) != null ? ref['value'] : void 0);
  updateLandfillStatus((ref1 = inputs['landfill_type']) != null ? ref1['value'] : void 0);
  updateStateStatus((ref2 = inputs['state']) != null ? ref2['value'] : void 0);
  updateAnaerobicDigestionStatus(inputs);
  initListeners();
  return recordInputs();
};

initListeners = function() {
  $("input[name=transport_distance]").on('click', function() {
    return updateTransportStatus($(this).attr('id'));
  });
  $("input[name=landfill_type]").on('click', function() {
    return updateLandfillStatus($(this).attr('id'));
  });
  return $('#state').on('change', function() {
    return updateStateStatus($(this).val());
  });
};

updateTransportStatus = function(selectionId) {
  var doEnable;
  if (selectionId == null) {
    selectionId = 'transport_distance_default';
  }
  doEnable = selectionId === 'transport_distance_define';
  return $('.distance-table input').prop('disabled', !doEnable);
};

updateLandfillStatus = function(selectionId) {
  if (selectionId == null) {
    selectionId = 'landfill_type_national_average';
  }
  if (selectionId === 'landfill_type_lfg_recovery') {
    $('.type-lfg-sub-selection input, #landfill-characteristics-2 input, #landfill-characteristics-3 input').prop('disabled', false);
    return $('.type-lfg-sub-selection input:checked').trigger('change');
  } else if (selectionId === 'landfill_type_national_average') {
    $('.type-lfg-sub-selection input, #landfill-characteristics-2 input').prop('disabled', true);
    $('#landfill_gas_recovery_typical_operation').prop('checked', true);
    $('#landfill_gas_recovery_typical_operation').trigger('change');
    return $('#landfill-characteristics-3 input').prop('disabled', false);
  } else {
    $('.type-lfg-sub-selection input, #landfill-characteristics-2 input, #landfill-characteristics-3 input').prop('disabled', true);
    $('#landfill_gas_recovery_typical_operation').prop('checked', true);
    $('#landfill_gas_recovery_typical_operation').trigger('change');
    $('#landfill_moisture_national_average').prop('checked', true);
    return $('#landfill_moisture_national_average').trigger('change');
  }
};

updateStateStatus = function(selection) {
  var region;
  if (selection == null) {
    selection = 'National Average';
  }
  region = regions[selection];
  $('#location_display').html(region);
  $('#location').val(locationIds[region]);
  return $('#location').trigger('change');
};

updateAnaerobicDigestionStatus = function(inputs) {
  var alternative, baseline, dry_only, i, index, len, materials;
  dry_only = false;
  materials = Object.keys(inputs['materials']);
  for (i = 0, len = materials.length; i < len; i++) {
    index = materials[i];
    if (inputs['materials'][index]['dry_only_digestion']) {
      baseline = Number(inputs['materials'][index]['baseline_anaerobic_digestion']);
      alternative = Number(inputs['materials'][index]['alternative_anaerobic_digestion']);
      if (!isNaN(baseline) && !isNaN(alternative) && ((baseline !== 0) || (alternative !== 0))) {
        dry_only = true;
      }
    }
  }
  if (dry_only) {
    $('#anaerobic_digestion_wet').prop('disabled', true);
    $('#anaerobic_digestion_wet').prop('checked', false);
    return $('#anaerobic_digestion_dry').prop('checked', true);
  }
};
