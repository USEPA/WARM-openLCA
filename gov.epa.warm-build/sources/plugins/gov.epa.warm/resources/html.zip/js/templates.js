
jade = (function(exports){
/*!
 * Jade - runtime
 * Copyright(c) 2010 TJ Holowaychuk <tj@vision-media.ca>
 * MIT Licensed
 */

/**
 * Lame Array.isArray() polyfill for now.
 */

if (!Array.isArray) {
  Array.isArray = function(arr){
    return '[object Array]' == Object.prototype.toString.call(arr);
  };
}

/**
 * Lame Object.keys() polyfill for now.
 */

if (!Object.keys) {
  Object.keys = function(obj){
    var arr = [];
    for (var key in obj) {
      if (obj.hasOwnProperty(key)) {
        arr.push(key);
      }
    }
    return arr;
  }
}

/**
 * Merge two attribute objects giving precedence
 * to values in object `b`. Classes are special-cased
 * allowing for arrays and merging/joining appropriately
 * resulting in a string.
 *
 * @param {Object} a
 * @param {Object} b
 * @return {Object} a
 * @api private
 */

exports.merge = function merge(a, b) {
  var ac = a['class'];
  var bc = b['class'];

  if (ac || bc) {
    ac = ac || [];
    bc = bc || [];
    if (!Array.isArray(ac)) ac = [ac];
    if (!Array.isArray(bc)) bc = [bc];
    ac = ac.filter(nulls);
    bc = bc.filter(nulls);
    a['class'] = ac.concat(bc).join(' ');
  }

  for (var key in b) {
    if (key != 'class') {
      a[key] = b[key];
    }
  }

  return a;
};

/**
 * Filter null `val`s.
 *
 * @param {Mixed} val
 * @return {Mixed}
 * @api private
 */

function nulls(val) {
  return val != null;
}

/**
 * Render the given attributes object.
 *
 * @param {Object} obj
 * @param {Object} escaped
 * @return {String}
 * @api private
 */

exports.attrs = function attrs(obj, escaped){
  var buf = []
    , terse = obj.terse;

  delete obj.terse;
  var keys = Object.keys(obj)
    , len = keys.length;

  if (len) {
    buf.push('');
    for (var i = 0; i < len; ++i) {
      var key = keys[i]
        , val = obj[key];

      if ('boolean' == typeof val || null == val) {
        if (val) {
          terse
            ? buf.push(key)
            : buf.push(key + '="' + key + '"');
        }
      } else if (0 == key.indexOf('data') && 'string' != typeof val) {
        buf.push(key + "='" + JSON.stringify(val) + "'");
      } else if ('class' == key && Array.isArray(val)) {
        buf.push(key + '="' + exports.escape(val.join(' ')) + '"');
      } else if (escaped && escaped[key]) {
        buf.push(key + '="' + exports.escape(val) + '"');
      } else {
        buf.push(key + '="' + val + '"');
      }
    }
  }

  return buf.join(' ');
};

/**
 * Escape the given string of `html`.
 *
 * @param {String} html
 * @return {String}
 * @api private
 */

exports.escape = function escape(html){
  return String(html)
    .replace(/&(?!(\w+|\#\d+);)/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
};

/**
 * Re-throw the given `err` in context to the
 * the jade in `filename` at the given `lineno`.
 *
 * @param {Error} err
 * @param {String} filename
 * @param {String} lineno
 * @api private
 */

exports.rethrow = function rethrow(err, filename, lineno){
  if (!filename) throw err;

  var context = 3
    , str = require('fs').readFileSync(filename, 'utf8')
    , lines = str.split('\n')
    , start = Math.max(lineno - context, 0)
    , end = Math.min(lines.length, lineno + context);

  // Error context
  var context = lines.slice(start, end).map(function(line, i){
    var curr = i + start + 1;
    return (curr == lineno ? '  > ' : '    ')
      + curr
      + '| '
      + line;
  }).join('\n');

  // Alter exception message
  err.path = filename;
  err.message = (filename || 'Jade') + ':' + lineno
    + '\n' + context + '\n\n' + err.message;
  throw err;
};

  return exports;

})({});

jade.templates = {};
jade.render = function(node, template, data) {
  var tmp = jade.templates[template](data);
  node.innerHTML = tmp;
};

jade.templates["analysis-result-row"] = function(locals, attrs, escape, rethrow, merge
) {
attrs = attrs || jade.attrs; escape = escape || jade.escape; rethrow = rethrow || jade.rethrow; merge = merge || jade.merge;
var buf = [];
with (locals || {}) {
var interp;
var analysis_cell_with_note_mixin = function(title, enabled, value){
var block = this.block, attributes = this.attributes || {}, escaped = this.escaped || {};
buf.push('<td> <span');
buf.push(attrs({ 'title':(title), 'data-animation':('fade'), 'data-placement':('top'), "class": ('with-note') }, {"title":true,"data-animation":true,"data-placement":true}));
buf.push('>');
if ( !enabled)
{
buf.push('N/A');
}
else if ( value)
{
buf.push('' + escape((interp = formatNumber(value)) == null ? '' : interp) + '');
}
else
{
buf.push('' + escape((interp = formatNumber(0)) == null ? '' : interp) + '');
}
buf.push('</span></td>');
};
buf.push('<tr><td>' + escape((interp = material.name) == null ? '' : interp) + '</td>');
 var baseline = 'Baseline Generation of Material (Tons)';
 var projectedSourceReduction = 'Baseline Source Reduction (Tons)';
 var annualSourceReduction = type + ' from Source Reduction (' + unit + ')';
 var projectedRecycling = 'Baseline Recycling (Tons)';
 var annualRecycling = type + ' from Recycling (' + unit + ')';
 var projectedLandfilling = 'Baseline Landfilling (Tons)';
 var annualLandfilling = type + ' from Landfilling (' + unit + ')';
 var projectedCombustion = 'Baseline Combustion (Tons)';
 var annualCombustion = type + ' from Combustion (' + unit + ')';
 var projectedComposting = 'Baseline Composting (Tons)';
 var annualComposting = type + ' from Composting (' + unit + ')';
 var projectedAnaerobicDigestion = 'Baseline Anaerobic Digestion (Tons)';
 var annualAnaerobicDigestion = type + ' from Anaerobic Digestion (' + unit + ')';
 var total = 'Total Annual ' + type + ' (' + unit + ')';
 var type = isAlternative?'alternative':'baseline';
analysis_cell_with_note_mixin(baseline, true, material['baseline']);
if ( isAlternative)
{
analysis_cell_with_note_mixin(projectedSourceReduction, !material.disabled.source_reduction, material['alternative_source_reduction']);
analysis_cell_with_note_mixin(annualSourceReduction, unit !== "labor-hours" && unit !== "$" && !material.disabled.source_reduction, material['alternative_source_reduction_result']);
}
analysis_cell_with_note_mixin(projectedRecycling, !material.disabled.recycling, material[type + '_recycling']);
analysis_cell_with_note_mixin(annualRecycling, !material.disabled.recycling, material[type + '_recycling_result']);
analysis_cell_with_note_mixin(projectedLandfilling, !material.disabled.landfilling, material[type + '_landfilling']);
analysis_cell_with_note_mixin(annualLandfilling, !material.disabled.landfilling, material[type + '_landfilling_result']);
analysis_cell_with_note_mixin(projectedCombustion, !material.disabled.combustion, material[type + '_combustion']);
analysis_cell_with_note_mixin(annualCombustion, !material.disabled.combustion, material[type + '_combustion_result']);
analysis_cell_with_note_mixin(projectedComposting, !material.disabled.composting, material[type + '_composting']);
analysis_cell_with_note_mixin(annualComposting, !material.disabled.composting, material[type + '_composting_result']);
analysis_cell_with_note_mixin(projectedAnaerobicDigestion, !material.disabled.digested, material[type + '_anaerobic_digestion']);
analysis_cell_with_note_mixin(annualAnaerobicDigestion, !material.disabled.digested, material[type + '_anaerobic_digestion_result']);
analysis_cell_with_note_mixin(total, true, material[type + '_result']);
buf.push('{unit}</tr>');
}
return buf.join("");
}
jade.templates["increment-result-row"] = function(locals, attrs, escape, rethrow, merge
) {
attrs = attrs || jade.attrs; escape = escape || jade.escape; rethrow = rethrow || jade.rethrow; merge = merge || jade.merge;
var buf = [];
with (locals || {}) {
var interp;
var incremental_cell_with_note_mixin = function(title, enabled, value){
var block = this.block, attributes = this.attributes || {}, escaped = this.escaped || {};
buf.push('<td> <span');
buf.push(attrs({ 'title':(title), 'data-animation':('fade'), 'data-placement':('top'), "class": ('with-note') }, {"title":true,"data-animation":true,"data-placement":true}));
buf.push('>');
if ( !enabled)
{
buf.push('N/A');
}
else if ( value)
{
buf.push('' + escape((interp = formatNumber(value)) == null ? '' : interp) + '');
}
else
{
buf.push('0');
}
buf.push('</span></td>');
};
buf.push('<tr><td>' + escape((interp = material.name) == null ? '' : interp) + '</td>');
 var sourceReductionInput = 'Source Reduction (Tons)';
 var sourceReductionResult = 'Incremental ' + type + ' from Source Reduction (' + unit + ')'; 
 var recyclingInput = 'Incremental Recycling (Tons)';
 var recyclingResult = 'Incremental ' + type + ' from Recycling (' + unit + ')'; 
 var landfillingInput = 'Incremental Landfilling (Tons)';
 var landfillingResult = 'Incremental ' + type + ' from Landfilling (' + unit + ')'; 
 var combustionInput = 'Incremental Combustion (Tons)';
 var combustionResult = 'Incremental ' + type + ' from Combustion (' + unit + ')'; 
 var compostingInput = 'Incremental Composting (Tons)';
 var compostingResult = 'Incremental ' + type + ' from Composting (' + unit + ')';
 var digestedInput = 'Incremental Anaerobic Digestion (Tons)';
 var digestedResult = 'Incremental ' + type + ' from Anaerobic Digestion (' + unit + ')'; 
 var totalResult = 'Total Incremental ' + type + ' (' + unit + ')'; 
incremental_cell_with_note_mixin(sourceReductionInput, !material.disabled.source_reduction, material.source_reduction_input_change);
incremental_cell_with_note_mixin(sourceReductionResult, unit !== "labor-hours" && unit !== "$" && !material.disabled.source_reduction, material.source_reduction_output_change);
incremental_cell_with_note_mixin(recyclingInput, !material.disabled.recycling, material.recycling_input_change);
incremental_cell_with_note_mixin(recyclingResult, !material.disabled.recycling, material.recycling_output_change);
incremental_cell_with_note_mixin(landfillingInput, !material.disabled.landfilling, material.landfilling_input_change);
incremental_cell_with_note_mixin(landfillingResult, !material.disabled.landfilling, material.landfilling_output_change);
incremental_cell_with_note_mixin(combustionInput, !material.disabled.combustion, material.combustion_input_change);
incremental_cell_with_note_mixin(combustionResult, !material.disabled.combustion, material.combustion_output_change);
incremental_cell_with_note_mixin(compostingInput, !material.disabled.composting, material.composting_input_change);
incremental_cell_with_note_mixin(compostingResult, !material.disabled.composting, material.composting_output_change);
incremental_cell_with_note_mixin(digestedInput, !material.disabled.digested, material.anaerobic_digestion_input_change);
incremental_cell_with_note_mixin(digestedResult, !material.disabled.digested, material.anaerobic_digestion_output_change);
incremental_cell_with_note_mixin(totalResult, true, material.output_change);
buf.push('</tr>');
}
return buf.join("");
}
jade.templates["material-selection"] = function(locals, attrs, escape, rethrow, merge
) {
attrs = attrs || jade.attrs; escape = escape || jade.escape; rethrow = rethrow || jade.rethrow; merge = merge || jade.merge;
var buf = [];
with (locals || {}) {
var interp;
buf.push('<div class="modal material-selection"><div class="modal-dialog"><div class="modal-content"><div class="modal-header"><button type="button" data-dismiss="modal" class="close"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button><h4 class="modal-title">Select materials to include</h4></div><div class="modal-body clearfix"> <div>Please select up to 6 materials to be shown in the chart:</div>');
// iterate materials
;(function(){
  if ('number' == typeof materials.length) {
    for (var index = 0, $$l = materials.length; index < $$l; index++) {
      var material = materials[index];

buf.push('<label class="checkbox-inline"><input');
buf.push(attrs({ 'type':('checkbox'), 'id':('material-' + (index) + ''), 'value':(material) }, {"type":true,"id":true,"value":true}));
buf.push('/>' + escape((interp = material) == null ? '' : interp) + '</label>');
    }
  } else {
    for (var index in materials) {
      var material = materials[index];

buf.push('<label class="checkbox-inline"><input');
buf.push(attrs({ 'type':('checkbox'), 'id':('material-' + (index) + ''), 'value':(material) }, {"type":true,"id":true,"value":true}));
buf.push('/>' + escape((interp = material) == null ? '' : interp) + '</label>');
   }
  }
}).call(this);

buf.push('</div><div class="modal-footer"><button id="apply-selection" type="button" class="btn btn-warm">Apply selection</button></div></div></div></div>');
}
return buf.join("");
}
jade.templates["per-ton-result-row"] = function(locals, attrs, escape, rethrow, merge
) {
attrs = attrs || jade.attrs; escape = escape || jade.escape; rethrow = rethrow || jade.rethrow; merge = merge || jade.merge;
var buf = [];
with (locals || {}) {
var interp;
var per_ton_cell_with_note_mixin = function(title, enabled, value){
var block = this.block, attributes = this.attributes || {}, escaped = this.escaped || {};
buf.push('<td> <span');
buf.push(attrs({ 'title':(title), 'data-animation':('fade'), 'data-placement':('top'), "class": ('with-note') }, {"title":true,"data-animation":true,"data-placement":true}));
buf.push('>');
if ( !enabled)
{
buf.push('N/A');
}
else if ( value)
{
buf.push('' + escape((interp = formatNumber(value)) == null ? '' : interp) + '');
}
else
{
buf.push('0');
}
buf.push('</span></td>');
};
buf.push('<tr><td>' + escape((interp = material.name) == null ? '' : interp) + '</td>');
 var emissionsPerTonTitle = type + ' per ton of material produced (' + unit + ')';
 var sourceReductionTitle = type + ' per Ton of Material Source Reduced (' + unit + ')';
 var recyclingTitle = type + ' per Ton of Material Recycled (' + unit + ')';
 var landfillingTitle = type + ' per Ton of Material Landfilled (' + unit + ')';
 var combustionTitle = type + ' per Ton of Material Combusted (' + unit + ')';
 var compostingTitle = type + ' per Ton of Material Composted (' + unit + ')';
 var anaerobicTitle = type + ' per Ton of Material Anaerobically Digested (' + unit + ')';
if ( type !== 'Labor Hours' && type !== 'Wages' && type !== 'Taxes')
{
per_ton_cell_with_note_mixin(emissionsPerTonTitle, unit !== "$" && unit !== "labor-hours" && !material.disabled.source_reduction, -1.0*material['per_ton_source_reduction_result']);
}
per_ton_cell_with_note_mixin(sourceReductionTitle, unit !== "$" && unit !== "labor-hours" && !material.disabled.source_reduction, material['per_ton_source_reduction_result']);
per_ton_cell_with_note_mixin(recyclingTitle, !material.disabled.recycling, material['per_ton_recycling_result']);
per_ton_cell_with_note_mixin(landfillingTitle, !material.disabled.landfilling, material['per_ton_landfilling_result']);
per_ton_cell_with_note_mixin(combustionTitle, !material.disabled.combustion, material['per_ton_combustion_result']);
per_ton_cell_with_note_mixin(compostingTitle, !material.disabled.composting, material['per_ton_composting_result']);
per_ton_cell_with_note_mixin(anaerobicTitle, !material.disabled.digested, material['per_ton_anaerobic_digestion_result']);
buf.push('</tr>');
}
return buf.join("");
}
jade.templates["production-result-row"] = function(locals, attrs, escape, rethrow, merge
) {
attrs = attrs || jade.attrs; escape = escape || jade.escape; rethrow = rethrow || jade.rethrow; merge = merge || jade.merge;
var buf = [];
with (locals || {}) {
var interp;
var production_cell_with_note_mixin = function(title, enabled, value){
var block = this.block, attributes = this.attributes || {}, escaped = this.escaped || {};
buf.push('<td> <span');
buf.push(attrs({ 'title':(title), 'data-animation':('fade'), 'data-placement':('top'), "class": ('with-note') }, {"title":true,"data-animation":true,"data-placement":true}));
buf.push('>');
if ( !enabled)
{
buf.push('N/A');
}
else if ( value)
{
buf.push('' + escape((interp = formatNumber(value)) == null ? '' : interp) + '');
}
else
{
buf.push('0.00');
}
buf.push('</span></td>');
};
buf.push('<tr>');
if ( material.note)
{
buf.push('<td class="material"><span');
buf.push(attrs({ 'title':(material.note.text), 'data-animation':('fade'), 'data-placement':('bottom'), "class": ('with-note') }, {"title":true,"data-animation":true,"data-placement":true}));
buf.push('>' + escape((interp = material.name) == null ? '' : interp) + '<sup>' + escape((interp = material.note.no) == null ? '' : interp) + '</sup></span></td>');
}
else
{
buf.push('<td class="material">' + escape((interp = material.name) == null ? '' : interp) + '</td>');
}
buf.push('<td class="invisible"></td>');
 baseline_emissions_label = 'Baseline Scenario - '+type+' from Production ('+unit+')'
 baseline_recycling_label = 'Baseline Scenario - '+type+' from Recycling ('+unit+')'
 baseline_landfilling_label = 'Baseline Scenario - '+type+' from Landfilling ('+unit+')'
 baseline_combustion_label = 'Baseline Scenario - '+type+' from Combustion ('+unit+')'
 baseline_composting_label = 'Baseline Scenario - '+type+' from Composting ('+unit+')'
 baseline_digested_label = 'Baseline Scenario - '+type+' from Anaerobic Digestion ('+unit+')'
 baseline_impact_label = 'Baseline Scenario - Production + End-Of-Life Impact ('+unit+')'
 baseline_emissions = material['per_ton_source_reduction_result'] ? -1.0*parseFloat(material['per_ton_source_reduction_result']) * parseFloat(material['baseline']) : 0
 baseline_recycling =  material['baseline_recycling_result'] ? parseFloat(material['baseline_recycling_result']) : 0
 baseline_landfilling = material['baseline_landfilling_result'] ? parseFloat(material['baseline_landfilling_result']) : 0
 baseline_combustion = material['baseline_combustion_result'] ? parseFloat(material['baseline_combustion_result']) : 0
 baseline_composting = material['baseline_composting_result'] ? parseFloat(material['baseline_composting_result']) : 0
 baseline_digested = material['baseline_anaerobic_digestion_result'] ? parseFloat(material['baseline_anaerobic_digestion_result']) : 0
 baseline_impact = baseline_emissions + baseline_recycling + baseline_landfilling + baseline_combustion + baseline_composting + baseline_digested
production_cell_with_note_mixin(baseline_emissions_label, true, baseline_emissions);
production_cell_with_note_mixin(baseline_recycling_label, !material.disabled.recycling, baseline_recycling);
production_cell_with_note_mixin(baseline_landfilling_label, !material.disabled.landfilling, baseline_landfilling);
production_cell_with_note_mixin(baseline_combustion_label, !material.disabled.combustion, baseline_combustion);
production_cell_with_note_mixin(baseline_composting_label, !material.disabled.composting, baseline_composting);
production_cell_with_note_mixin(baseline_digested_label, !material.disabled.digested, baseline_digested);
production_cell_with_note_mixin(baseline_impact_label, true, baseline_impact);
buf.push('<td class="invisible"></td>');
 alternative_emissions_label = 'Alternative Scenario - '+type+' from Production ('+unit+')'
 alternative_recycling_label = 'Alternative Scenario - '+type+' from Recycling ('+unit+')'
 alternative_landfilling_label = 'Alternative Scenario - '+type+' from Landfilling ('+unit+')'
 alternative_combustion_label = 'Alternative Scenario - '+type+' from Combustion ('+unit+')'
 alternative_composting_label = 'Alternative Scenario - '+type+' from Composting ('+unit+')'
 alternative_digested_label = 'Alternative Scenario - '+type+' from Anaerobic Digestion ('+unit+')'
 alternative_impact_label = 'Alternative Scenario - Production + End-Of-Life Impact ('+unit+')'
 alternative_emissions = material['per_ton_source_reduction_result'] ? -1.0*parseFloat(material['per_ton_source_reduction_result']) * parseFloat(material['baseline']) + parseFloat(material['alternative_source_reduction_result']) : 0
 alternative_recycling =  material['alternative_recycling_result'] ? parseFloat(material['alternative_recycling_result']) : 0
 alternative_landfilling = material['alternative_landfilling_result'] ? parseFloat(material['alternative_landfilling_result']) : 0
 alternative_combustion = material['alternative_combustion_result'] ? parseFloat(material['alternative_combustion_result']) : 0
 alternative_composting = material['alternative_composting_result'] ? parseFloat(material['alternative_composting_result']) : 0
 alternative_digested = material['alternative_anaerobic_digestion_result'] ? parseFloat(material['alternative_anaerobic_digestion_result']) : 0
 alternative_impact = alternative_emissions + alternative_recycling + alternative_landfilling + alternative_combustion + alternative_composting + alternative_digested
production_cell_with_note_mixin(alternative_emissions_label, true, alternative_emissions);
production_cell_with_note_mixin(alternative_recycling_label, !material.disabled.recycling, alternative_recycling);
production_cell_with_note_mixin(alternative_landfilling_label, !material.disabled.landfilling, alternative_landfilling);
production_cell_with_note_mixin(alternative_combustion_label, !material.disabled.combustion, alternative_combustion);
production_cell_with_note_mixin(alternative_composting_label, !material.disabled.composting, alternative_composting);
production_cell_with_note_mixin(alternative_digested_label, !material.disabled.digested, alternative_digested);
production_cell_with_note_mixin(alternative_impact_label, true, alternative_impact);
buf.push('</tr>');
}
return buf.join("");
}
jade.templates["scenario-row"] = function(locals, attrs, escape, rethrow, merge
) {
attrs = attrs || jade.attrs; escape = escape || jade.escape; rethrow = rethrow || jade.rethrow; merge = merge || jade.merge;
var buf = [];
with (locals || {}) {
var interp;
var scenario_cell_mixin = function(id, title, enabled){
var block = this.block, attributes = this.attributes || {}, escaped = this.escaped || {};
buf.push('<td>');
if ( enabled)
{
buf.push('<input');
buf.push(attrs({ 'id':(id), 'name':(id), 'type':('text'), 'size':('6'), 'title':(title), 'data-animation':('fade'), 'data-placement':('top'), 'value':('0'), "class": ('material-input') + ' ' + ('form-control') + ' ' + ('control-xs') }, {"id":true,"name":true,"type":true,"size":true,"title":true,"data-animation":true,"data-placement":true,"value":true}));
buf.push('/>');
}
else
{
buf.push('<span');
buf.push(attrs({ 'title':(title), 'data-animation':('fade'), 'data-placement':('top'), "class": ('with-note') }, {"title":true,"data-animation":true,"data-placement":true}));
buf.push('>N/A</span>');
}
buf.push('</td>');
};
buf.push('<tr');
buf.push(attrs({ 'data-index':(index) }, {"data-index":true}));
buf.push('><td class="invisible error-indicator"></td>');
if ( material.note)
{
buf.push('<td class="material"><span');
buf.push(attrs({ 'title':(material.note.text), 'data-animation':('fade'), 'data-placement':('right'), "class": ('with-note') }, {"title":true,"data-animation":true,"data-placement":true}));
buf.push('>' + escape((interp = material.name) == null ? '' : interp) + '<sup>' + escape((interp = material.note.no) == null ? '' : interp) + '</sup></span></td>');
}
else
{
buf.push('<td class="material">' + escape((interp = material.name) == null ? '' : interp) + '</td>');
}
buf.push('<td class="invisible"></td>');
scenario_cell_mixin('baseline_recycling', 'Base scenario - Tons recycled', !material.disabled.recycling);
scenario_cell_mixin('baseline_landfilling', 'Base scenario - Tons landfilled', !material.disabled.landfilling);
scenario_cell_mixin('baseline_combustion', 'Base scenario - Tons combusted', !material.disabled.combustion);
scenario_cell_mixin('baseline_composting', 'Base scenario - Tons composted', !material.disabled.composting);
if ( material.note_digested)
{
scenario_cell_mixin('baseline_anaerobic_digestion', material.note_digested, !material.disabled.digested);
}
else
{
scenario_cell_mixin('baseline_anaerobic_digestion', 'Base scenario - Tons anaerobically digested', !material.disabled.digested);
}
buf.push('<td class="invisible"></td><td id="baseline_total">0</td><td class="invisible"></td>');
scenario_cell_mixin('alternative_source_reduction', 'Alternative scenario - Tons source reduced', !material.disabled.source_reduction);
scenario_cell_mixin('alternative_recycling', 'Alternative scenario - Tons recycled', !material.disabled.recycling);
scenario_cell_mixin('alternative_landfilling', 'Alternative scenario - Tons landfilled', !material.disabled.landfilling);
scenario_cell_mixin('alternative_combustion', 'Alternative scenario - Tons combusted', !material.disabled.combustion);
scenario_cell_mixin('alternative_composting', 'Alternative scenario - Tons composted', !material.disabled.composting);
if ( material.note_digested)
{
scenario_cell_mixin('alternative_anaerobic_digestion', material.note_digested, !material.disabled.digested);
}
else
{
scenario_cell_mixin.call({
block: function(){
buf.push('	');
}
}, 'alternative_anaerobic_digestion', 'Alternative scenario - Tons anaerobically digested', !material.disabled.digested);
}
buf.push('</tr>');
}
return buf.join("");
}
jade.templates["summary-result-row"] = function(locals, attrs, escape, rethrow, merge
) {
attrs = attrs || jade.attrs; escape = escape || jade.escape; rethrow = rethrow || jade.rethrow; merge = merge || jade.merge;
var buf = [];
with (locals || {}) {
var interp;
var summary_cell_with_note_mixin = function(title, enabled, value){
var block = this.block, attributes = this.attributes || {}, escaped = this.escaped || {};
buf.push('<td> <span');
buf.push(attrs({ 'title':(title), 'data-animation':('fade'), 'data-placement':('top'), "class": ('with-note') }, {"title":true,"data-animation":true,"data-placement":true}));
buf.push('>');
if ( !enabled)
{
buf.push('N/A');
}
else if ( value)
{
buf.push('' + escape((interp = formatNumber(value)) == null ? '' : interp) + '');
}
else
{
buf.push('0');
}
buf.push('</span></td>');
};
buf.push('<tr');
buf.push(attrs({ 'data-index':(index) }, {"data-index":true}));
buf.push('>');
if ( material.note)
{
buf.push('<td class="material"><span');
buf.push(attrs({ 'title':(material.note.text), 'data-animation':('fade'), 'data-placement':('bottom'), "class": ('with-note') }, {"title":true,"data-animation":true,"data-placement":true}));
buf.push('>' + escape((interp = material.name) == null ? '' : interp) + '<sup>' + escape((interp = material.note.no) == null ? '' : interp) + '</sup></span></td>');
}
else
{
buf.push('<td class="material">' + escape((interp = material.name) == null ? '' : interp) + '</td>');
}
buf.push('<td class="invisible"></td>');
summary_cell_with_note_mixin('Base scenario - Tons recycled', !material.disabled.recycling, material['baseline_recycling']);
summary_cell_with_note_mixin('Base scenario - Tons landfilled', !material.disabled.landfilling, material['baseline_landfilling']);
summary_cell_with_note_mixin('Base scenario - Tons combusted', !material.disabled.combustion, material['baseline_combustion']);
summary_cell_with_note_mixin('Base scenario - Tons composted', !material.disabled.composting, material['baseline_composting']);
summary_cell_with_note_mixin('Base scenario - Tons anaerobically digested', !material.disabled.digested, material['baseline_anaerobic_digestion']);
buf.push('<!-- *** material.disabled.composting = #{ material.disabled.composting }, material.disabled.digested = #{ material.disabled.digested } ***-->');
summary_cell_with_note_mixin('Base scenario - Total MTCO2E', true, material['baseline_result']);
buf.push('<td class="invisible"></td>');
summary_cell_with_note_mixin('Alternative scenario - Tons reduced', !material.disabled.source_reduction, material['alternative_source_reduction']);
summary_cell_with_note_mixin('Alternative scenario - Tons recycled', !material.disabled.recycling, material['alternative_recycling']);
summary_cell_with_note_mixin('Alternative scenario - Tons landfilled', !material.disabled.landfilling, material['alternative_landfilling']);
summary_cell_with_note_mixin('Alternative scenario - Tons combusted', !material.disabled.combustion, material['alternative_combustion']);
summary_cell_with_note_mixin('Alternative scenario - Tons composted', !material.disabled.composting, material['alternative_composting']);
summary_cell_with_note_mixin('Alternative scenario - Tons anaerobically digested', !material.disabled.digested, material['alternative_anaerobic_digestion']);
summary_cell_with_note_mixin('Alternative scenario - Total MTCO2E', true, material['alternative_result']);
buf.push('<td class="invisible"></td>');
summary_cell_with_note_mixin('Change [Alt-Base] MTCO2E', true, material['change']);
buf.push('</tr>');
}
return buf.join("");
}