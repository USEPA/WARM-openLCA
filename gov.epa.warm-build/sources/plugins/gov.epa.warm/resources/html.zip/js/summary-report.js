var fillSummaryTable, initializeSummary, setEquivalents, setSummaryResults;

initializeSummary = function() {
  return $('.with-note').tooltip();
};

setSummaryResults = function(materials, equivalents, baselineTotal, alternativeTotal) {
  fillSummaryTable(materials);
  setEquivalents(equivalents);
  $('#total-change').html(numeral(alternativeTotal - baselineTotal).format('0.00'));
  $('.result-table #total-baseline').html(numeral(baselineTotal).format('0.00'));
  $('.result-table #total-alternative').html(numeral(alternativeTotal).format('0.00'));
  $('.with-note').tooltip();
  return null;
};

fillSummaryTable = function(materials) {
  var i, index, len, result, results, results1, stack;
  results = JSON.parse(materials);
  index = 1;
  stack = [];
  for (i = 0, len = results.length; i < len; i++) {
    result = results[i];
    stack.push(result);
  }
  results1 = [];
  while (stack.length !== 0) {
    results1.push($('.result-table tbody').prepend(jade.templates['summary-result-row']({
      material: stack.pop(),
      index: index++,
      formatNumber: formatNumber
    })));
  }
  return results1;
};

setEquivalents = function(equivalentsString) {
  var box, doShow, equivalents, i, id, len, ref, results1, value;
  equivalents = JSON.parse(equivalentsString);
  ref = Object.keys(equivalents);
  results1 = [];
  for (i = 0, len = ref.length; i < len; i++) {
    id = ref[i];
    value = equivalents[id];
    if (id.indexOf('annual') !== -1) {
      value = Math.abs(formatNumber(value, 5));
      doShow = parseInt(value * 100000) >= 1;
    } else {
      value = parseInt(Math.abs(value));
      doShow = value >= 1;
    }
    box = $("#" + id + ".equivalent");
    if (doShow) {
      box.removeClass('hidden');
      if (equivalents[id] >= 0) {
        $('.positive-prefix', box).removeClass('hidden');
        $('.negative-prefix', box).addClass('hidden');
      } else {
        $('.positive-prefix', box).addClass('hidden');
        $('.negative-prefix', box).removeClass('hidden');
      }
      results1.push($('.equivalent-value', box).html(value));
    } else {
      results1.push(box.addClass('hidden'));
    }
  }
  return results1;
};

initializeSummary();
