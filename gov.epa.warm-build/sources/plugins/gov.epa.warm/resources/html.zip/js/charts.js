var availableMaterials, chartData, charts, collectFieldValues, currentTab, fillLegend, groupedContributionsLoaded, initializeCharts, materialContributionsLoaded, materialWeightContributionsLoaded, productionEOLContributionsLoaded, selectMaterials, setAvailableMaterials, subtypeContributionsLoaded, updateChart, updateChartLabels;

materialContributionsLoaded = false;

subtypeContributionsLoaded = false;

groupedContributionsLoaded = false;

materialWeightContributionsLoaded = false;

productionEOLContributionsLoaded = false;

currentTab = 'flowContributions';

availableMaterials = [];

charts = {};

chartData = {};

setAvailableMaterials = function(materials) {
  availableMaterials = JSON.parse(materials);
  return null;
};

initializeCharts = function() {
  return $('#chart-tabs > li > a').on('click', function() {
    var href, id, tab;
    tab = $(this);
    href = tab.attr('href');
    id = href.substring(1, href.length - 3);
    currentTab = id;
    if (id === 'materialContributions' && !materialContributionsLoaded) {
      materialContributionsLoaded = true;
      if (typeof applyFilterToMaterialContributions === "function") {
        applyFilterToMaterialContributions();
      }
    } else if (id === 'subtypeContributions' && !subtypeContributionsLoaded) {
      subtypeContributionsLoaded = true;
      if (typeof applyFilterToSubtypeContributions === "function") {
        applyFilterToSubtypeContributions();
      }
    } else if (id === 'groupedContributions' && !groupedContributionsLoaded) {
      groupedContributionsLoaded = true;
      if (typeof loadGroupedContributions === "function") {
        loadGroupedContributions();
      }
    } else if (id === 'materialWeightContributions' && !materialWeightContributionsLoaded) {
      materialWeightContributionsLoaded = true;
      if (typeof applyFilterToMaterialWeightContributions === "function") {
        applyFilterToMaterialWeightContributions();
      }
    } else if (id === 'productionEOLContributions' && !productionEOLContributionsLoaded) {
      productionEOLContributionsLoaded = true;
      if (typeof loadProductionEOLContributions === "function") {
        loadProductionEOLContributions();
      }
    } else {
      setTimeout(function() {
        return updateChart(chartData[id]);
      }, 100);
    }
    return $('.open-material-selection').on('click', function(event) {
      return selectMaterials();
    });
  });
};

selectMaterials = function() {
  var i, len, material, materialNames, modal;
  materialNames = [];
  for (i = 0, len = availableMaterials.length; i < len; i++) {
    material = availableMaterials[i];
    materialNames.push(material.name);
  }
  modal = jade.templates['material-selection']({
    materials: materialNames
  });
  if ($('.modal')) {
    $('.modal').modal('hide');
    $('.modal').remove();
  }
  $('body').append(modal);
  $('.modal').modal();
  $('.modal input').on('click', function(event) {
    var count, target, value;
    target = event.target || event.srcElement || event.originalTarget;
    value = $(target).is(':checked');
    count = $('.modal input:checked').length;
    if (value && count === 7) {
      if (event.preventDefault) {
        event.preventDefault();
      } else {
        event.returnValue = false;
      }
      return alert('You can only select 6 materials at a time');
    }
  });
  return $('.modal button#apply-selection').on('click', function(event) {
    var element, j, len1, ref, selection;
    selection = '';
    ref = $('.modal input:checked');
    for (j = 0, len1 = ref.length; j < len1; j++) {
      element = ref[j];
      element = $(element);
      if (selection) {
        selection += '@';
      }
      selection += element.val();
    }
    if (selection) {
      $('.modal').modal('hide');
      $('.modal').remove();
      if (currentTab === 'materialContributions') {
        return applyFilterToMaterialContributions(selection);
      } else if (currentTab === 'materialWeightContributions') {
        return applyFilterToMaterialWeightContributions(selection);
      } else if (currentTab === 'subtypeContributions') {
        return applyFilterToSubtypeContributions(selection);
      }
    }
  });
};

updateChart = function(data) {
  var chartClass, i, id, j, len, len1, max, min, options, ref, ref1, series, value;
  id = data.identifier;
  chartData[id] = data;
  min = 0;
  max = 0;
  ref = data.series;
  for (i = 0, len = ref.length; i < len; i++) {
    series = ref[i];
    if ($.isArray(series)) {
      for (j = 0, len1 = series.length; j < len1; j++) {
        value = series[j];
        if (value.value || value.value === 0) {
          value = value.value;
        }
        min = Math.min(min, value);
        max = Math.max(max, value);
      }
    } else {
      min = Math.min(min, series);
      max = Math.max(max, series);
    }
  }
  options = {
    high: Math.ceil(max),
    low: Math.floor(min),
    axisX: {
      offset: 60
    },
    plugins: [Chartist.plugins.tooltip()]
  };
  if (id === "materialWeightContributions") {
    $(".yaxis-label-alternate").show();
    $(".yaxis-label").hide();
  } else {
    $(".yaxis-label-alternate").hide();
    $(".yaxis-label").show();
  }
  if (id === "productionEOLContributions") {
    options.stackBars = true;
    options.stackMode = "overlap";
    options.seriesBarDistance = 80;
    $("#" + id + "Tab").removeClass('one-bar-per-series two-bar-per-series three-bar-per-series four-bar-per-series five-bar-per-series six-bar-per-series seven-bar-per-series');
    chartClass = 'six-bar-per-series-productionEOL';
    $("#" + id + "Tab").addClass(chartClass);
  } else {
    switch (data.series.length) {
      case 1:
        options.seriesBarDistance = 160;
        break;
      case 2:
        options.seriesBarDistance = 40;
        break;
      case 4:
        options.seriesBarDistance = 20;
        break;
      case 6:
        options.seriesBarDistance = 18;
        break;
      case 8:
        options.seriesBarDistance = 16;
        break;
      case 10:
        options.seriesBarDistance = 14;
        break;
      case 12:
        options.seriesBarDistance = 12;
        break;
      case 14:
        options.seriesBarDistance = 10;
    }
    $("#" + id + "Tab").removeClass('one-bar-per-series two-bar-per-series three-bar-per-series four-bar-per-series five-bar-per-series six-bar-per-series seven-bar-per-series');
    switch (data.series.length) {
      case 1:
        chartClass = 'one-bar-per-series';
        break;
      case 2:
        chartClass = 'one-bar-per-series';
        break;
      case 4:
        chartClass = 'two-bar-per-series';
        break;
      case 6:
        chartClass = 'three-bar-per-series';
        break;
      case 8:
        chartClass = 'four-bar-per-series';
        break;
      case 10:
        chartClass = 'five-bar-per-series';
        break;
      case 12:
        chartClass = 'six-bar-per-series';
        break;
      case 14:
        chartClass = 'seven-bar-per-series';
    }
    $("#" + id + "Tab").addClass(chartClass);
  }
  $("#" + id).height($(window).innerHeight() - 300);
  options.height = $(window).innerHeight() - 300;
  options.width = $(window).innerWidth() - 450;
  charts[id] = new Chartist.Bar("#" + id, data, options, []);
  if ((ref1 = data.legend) != null ? ref1.length : void 0) {
    fillLegend(id, data.legend);
  } else {
    $('.ct-legend', "#" + id + "Tab").addClass('hidden');
  }
  return null;
};

updateChartLabels = function(type) {
  var i, len, ref, xaxis_div, xaxis_id, yaxis, yaxis_alternate;
  yaxis = $('.yaxis-label');
  yaxis_alternate = $('.yaxis-label-alternate');
  yaxis_alternate.text("Short Tons");
  if (type === "MTCE") {
    yaxis.text("Metric Tons of Carbon Equivalent (MTCE)");
  } else if (type === "MTCO2E") {
    yaxis.text("Metric Tons of Carbon Dioxide Equivalent (MTCO2E)");
  } else if (type === "ENERGY") {
    yaxis.text("Units of Energy (million BTU)");
  }
  ref = ["flowContributions", "subtypeContributions", "materialContributions", "groupedContributions", "materialWeightContributions", "productionEOLContributions"];
  for (i = 0, len = ref.length; i < len; i++) {
    xaxis_id = ref[i];
    xaxis_div = $("#" + xaxis_id + "-xaxis");
    if (xaxis_div) {
      if (xaxis_id === "flowContributions") {
        if (type === "MTCE" || type === "MTCO2E") {
          xaxis_div.text("Emissions or carbon storage type");
        } else {
          xaxis_div.text("Energy type");
        }
      } else if (xaxis_id === "materialWeightContributions") {
        xaxis_div.text("Material");
      } else if (xaxis_id === "productionEOLContributions") {
        xaxis_div.text("Material");
      } else if (xaxis_id === "subtypeContributions") {
        xaxis_div.text("Management practice");
      } else if (xaxis_id === "materialContributions") {
        xaxis_div.text("Material");
      } else if (xaxis_id === "groupedContributions") {
        if (type === "MTCE" || type === "MTCO2E") {
          xaxis_div.text("Emissions source/offset");
        } else {
          xaxis_div.text("Energy source/offset");
        }
      }
    }
  }
  return null;
};

fillLegend = function(id, labels) {
  var i, index, label, legend, len, letters;
  legend = $('.ct-legend', "#" + id + "Tab");
  legend.empty();
  letters = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n'];
  for (index = i = 0, len = labels.length; i < len; index = ++i) {
    label = labels[index];
    legend.append('<div><span class="ct-legend-entry ct-series-' + letters[index] + '">&nbsp;</span><span>' + label + '</span></div>');
  }
  return legend.removeClass('hidden');
};

collectFieldValues = function(entries, field) {
  var entry, i, len, values;
  values = [];
  for (i = 0, len = entries.length; i < len; i++) {
    entry = entries[i];
    values.push(entry[field]);
  }
  return values;
};

initializeCharts();
