var addCellValue, calculateScenarioRow, getIndex, getRow, initialize, markError, registerListeners, setCellValue, setMaterials, unmarkError;

initialize = function(data) {
  setMaterials(materials);
  setInputs(data);
  $('.table input, .with-note').tooltip();
  registerListeners();
  return recordInputs();
};

setMaterials = function(materials) {
  var i, index, len, material, notes, number, results, tableBody;
  tableBody = $('.scenario-table tbody');
  notes = $('.foot-notes');
  number = 0;
  results = [];
  for (index = i = 0, len = materials.length; i < len; index = ++i) {
    material = materials[index];
    if (material.note) {
      material.note = {
        no: ++number,
        text: material.note
      };
      notes.append("<p>" + number + ") " + material.note.text + "</p>");
    }
    results.push(tableBody.append(jade.templates['scenario-row']({
      material: material,
      index: index
    })));
  }
  return results;
};

registerListeners = function() {
  var i, len, ref, results, row;
  $('.table input').on('change', function() {
    var element, index;
    element = $(this);
    if (!element.val()) {
      element.val(0);
    }
    index = getIndex(element);
    return calculateScenarioRow(index);
  });
  $('.table input').on('click', function() {
    return $(this).select();
  });
  ref = $('tr[data-index]');
  results = [];
  for (i = 0, len = ref.length; i < len; i++) {
    row = ref[i];
    row = $(row);
    results.push(calculateScenarioRow(row.attr('data-index')));
  }
  return results;
};

getIndex = function(element) {
  while (!element.is('tr')) {
    element = element.parent();
  }
  return element.attr('data-index');
};

calculateScenarioRow = function(index) {
  var alternativeTotal, baselineTotal;
  baselineTotal = addCellValue('baseline_recycling', index, new Big(0));
  baselineTotal = addCellValue('baseline_landfilling', index, baselineTotal);
  baselineTotal = addCellValue('baseline_combustion', index, baselineTotal);
  baselineTotal = addCellValue('baseline_composting', index, baselineTotal);
  baselineTotal = addCellValue('baseline_anaerobic_digestion', index, baselineTotal);
  setCellValue('baseline_total', index, baselineTotal.toString());
  alternativeTotal = addCellValue('alternative_recycling', index, new Big(0));
  alternativeTotal = addCellValue('alternative_landfilling', index, alternativeTotal);
  alternativeTotal = addCellValue('alternative_combustion', index, alternativeTotal);
  alternativeTotal = addCellValue('alternative_composting', index, alternativeTotal);
  alternativeTotal = addCellValue('alternative_source_reduction', index, alternativeTotal);
  alternativeTotal = addCellValue('alternative_anaerobic_digestion', index, alternativeTotal);
  if (baselineTotal.eq(alternativeTotal)) {
    unmarkError(index);
  } else {
    markError(index);
  }
  ensureMaterialEntryExists(index);
  inputs['materials'][index]['baseline'] = baselineTotal.toString();
  return saveInputs(JSON.stringify(inputs));
};

addCellValue = function(type, index, total) {
  var cell;
  cell = $("#" + type, getRow(index));
  if (cell.length === 0) {
    return total;
  }
  return new Big(cell.val()).plus(new Big(total));
};

setCellValue = function(type, index, value) {
  var cell;
  cell = $("#" + type, getRow(index));
  if (cell.length) {
    return cell.html(value);
  }
};

getRow = function(index) {
  return $(".scenario-table > tbody > tr[data-index=" + index + "]");
};

markError = function(index) {
  var indicator, row;
  row = getRow(index);
  row.addClass('danger');
  indicator = $('td.error-indicator', row);
  indicator.removeClass('invisible');
  return indicator.html('!');
};

unmarkError = function(index) {
  var indicator, row;
  row = getRow(index);
  row.removeClass('danger');
  indicator = $('td.error-indicator', row);
  indicator.addClass('invisible');
  return indicator.html('');
};
