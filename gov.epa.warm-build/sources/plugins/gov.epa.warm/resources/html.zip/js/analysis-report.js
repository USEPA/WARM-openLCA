var fillAnalysisTable, initializeAnalysis, setAnalysisResults;

initializeAnalysis = function() {
  return $('.with-note').tooltip();
};

setAnalysisResults = function(materials, baselineTotal, alternativeTotal) {
  fillAnalysisTable(materials);
  $('.info-box #total-baseline').html(numeral(baselineTotal).format('0.00'));
  $('.info-box #total-alternative').html(numeral(alternativeTotal).format('0.00'));
  $('.info-box #total-change').html(numeral(alternativeTotal - baselineTotal).format('0.00'));
  $('.with-note').tooltip();
  return null;
};

fillAnalysisTable = function(materials) {
  var body, i, index, len, nextMaterial, result, results, results1, stack, type, unit;
  results = JSON.parse(materials);
  index = 1;
  stack = [];
  for (i = 0, len = results.length; i < len; i++) {
    result = results[i];
    stack.push(result);
  }
  body = $('body');
  type = body.attr('data-type');
  unit = body.attr('data-unit');
  results1 = [];
  while (stack.length !== 0) {
    nextMaterial = stack.pop();
    $('.per-ton-result-table tbody').prepend(jade.templates['per-ton-result-row']({
      material: nextMaterial,
      type: type,
      unit: unit,
      formatNumber: formatNumber
    }));
    $('.analysis-result-table[data-alternative=false] tbody').prepend(jade.templates['analysis-result-row']({
      material: nextMaterial,
      type: type,
      unit: unit,
      isAlternative: false,
      formatNumber: formatNumber
    }));
    $('.analysis-result-table[data-alternative=true] tbody').prepend(jade.templates['analysis-result-row']({
      material: nextMaterial,
      type: type,
      unit: unit,
      isAlternative: true,
      formatNumber: formatNumber
    }));
    results1.push($('.increment-table tbody').prepend(jade.templates['increment-result-row']({
      material: nextMaterial,
      type: type,
      unit: unit,
      formatNumber: formatNumber
    })));
  }
  return results1;
};

initializeAnalysis();
