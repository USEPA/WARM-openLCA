var ensureMaterialEntryExists, getIndex, getInputs, getMaterialName, getOrder, getOrderedKeys, getParentRow, getType, inputs, record, recordInputs, setInputs;

inputs = {};

setInputs = function(data, typeForAll) {
  var field, fields, i, id, index, input, inputField, j, k, keys, len, len1, len2, materials, row, type, value;
  if (data == null) {
    data = '{}';
  }
  inputs = JSON.parse(data);
  keys = getOrderedKeys(inputs);
  for (i = 0, len = keys.length; i < len; i++) {
    id = keys[i];
    if (id === 'materials') {
      continue;
    }
    input = inputs[id];
    value = input.value;
    type = typeForAll || input.type;
    switch (type) {
      case 'text':
        $("#" + id).val(value);
        break;
      case 'radio':
        $("#" + input.value).click();
        break;
      case 'select':
        $("#" + id + " option[value='" + value + "']").prop('selected', true);
        break;
      case 'date':
        $("#" + id).val(value);
        break;
      case 'element':
        if (input.type === 'date') {
          value = moment(value).format('MM/DD/YYYY');
        }
        $("#" + id).html(value);
    }
    if (type === 'text' || type === 'select') {
      $("#" + id).trigger('change');
    }
  }
  if (inputs['materials']) {
    materials = Object.keys(inputs['materials']);
    for (j = 0, len1 = materials.length; j < len1; j++) {
      index = materials[j];
      row = $("tr[data-index=" + index + "]");
      fields = Object.keys(inputs['materials'][index]);
      for (k = 0, len2 = fields.length; k < len2; k++) {
        field = fields[k];
        inputField = $("#" + field, row);
        inputField.val(inputs['materials'][index][field]);
        inputField.trigger('change');
      }
    }
  }
  return null;
};

getInputs = function() {
  return JSON.stringify(inputs);
};

recordInputs = function() {
  var i, input, len, ref, results;
  $('input, select, textarea').on('change', function() {
    return record($(this));
  });
  ref = $('input, select, textarea');
  results = [];
  for (i = 0, len = ref.length; i < len; i++) {
    input = ref[i];
    results.push(record($(input), false));
  }
  return results;
};

record = function(element, save) {
  var id, index, name, order, type, value;
  if (save == null) {
    save = true;
  }
  console.log(inputs);
  id = element.attr('id');
  value = element.val();
  type = getType(element);
  switch (type) {
    case 'material':
      index = getIndex(element);
      ensureMaterialEntryExists(index);
      inputs['materials'][index][id] = value;
      break;
    case 'radio':
      if (!element.is(':checked')) {
        return;
      }
      name = element.attr('name');
      order = getOrder(element);
      inputs[name] = {
        type: type,
        value: id,
        order: order
      };
      break;
    default:
      inputs[id] = {
        type: type,
        value: value
      };
  }
  if (save) {
    return saveInputs(JSON.stringify(inputs));
  }
};

getOrderedKeys = function(inputs) {
  var keys;
  keys = Object.keys(inputs);
  return keys.sort(function(a, b) {
    var order1, order2;
    order1 = 0;
    order2 = 0;
    if (inputs[a]['order']) {
      order1 = inputs[a]['order'];
    }
    if (inputs[b]['order']) {
      order2 = inputs[b]['order'];
    }
    return order1 - order2;
  });
};

getOrder = function(element) {
  while (!element.is('body') && !element.attr('data-order')) {
    element = element.parent();
  }
  return element.attr('data-order');
};

ensureMaterialEntryExists = function(index) {
  if (!inputs['materials']) {
    inputs['materials'] = {};
  }
  if (!inputs['materials'][index]) {
    return inputs['materials'][index] = materials[parseInt(index)];
  }
};

getType = function(element) {
  var isMaterialInput, type;
  if (element.is('select')) {
    return 'select';
  }
  if (element.is('textarea')) {
    return 'text';
  }
  if (element.is('input')) {
    isMaterialInput = element.hasClass('material-input');
    if (isMaterialInput) {
      return 'material';
    } else {
      type = element.attr('type');
      switch (type) {
        case 'text':
          return 'text';
        case 'date':
          return 'date';
        case 'hidden':
          return 'text';
        case 'radio':
          return 'radio';
      }
    }
  }
  return null;
};

getIndex = function(materialInput) {
  var row;
  row = getParentRow(materialInput);
  return row.attr('data-index');
};

getMaterialName = function(materialInput) {
  var materialCell, row, text;
  row = getParentRow(materialInput);
  materialCell = $('.material .with-note', row);
  if (!(materialCell != null ? materialCell.length : void 0)) {
    materialCell = $('.material', row);
  }
  text = materialCell.html();
  if (text.indexOf('<sup>') !== -1) {
    text = text.substring(0, text.indexOf('<sup>'));
  }
  return text;
};

getParentRow = function(materialInput) {
  var element;
  element = materialInput;
  while (!element.is('tr')) {
    element = element.parent();
  }
  return element;
};
