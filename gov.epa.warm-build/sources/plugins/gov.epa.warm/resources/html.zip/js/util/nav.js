var interceptLinks;

interceptLinks = function(selector, callback) {
  return $(selector).on('click', function(event) {
    var currentStep, href;
    if (event.preventDefault) {
      event.preventDefault();
    } else {
      event.returnValue = false;
    }
    event.doit = false;
    href = $(this).attr('href');
    currentStep = $(this).attr('data-current-step');
    if (parseInt(currentStep) === 1 && $('.scenario-table > tbody > tr[data-index].danger').length) {
      $('.modal').modal();
      return $('.modal').on('hide.bs.modal', function() {
        return typeof window[callback] === "function" ? window[callback](href) : void 0;
      });
    } else {
      return typeof window[callback] === "function" ? window[callback](href) : void 0;
    }
  });
};

interceptLinks('a.navigate', 'navigate');

interceptLinks('a.external', 'openInExternalBrowser');
