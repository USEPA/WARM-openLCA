var formatNumber;

$('.section-header').on('click', function() {
  var element;
  element = $('span.glyphicon', $(this));
  if (element.hasClass('glyphicon-chevron-down')) {
    element.removeClass('glyphicon-chevron-down');
    return element.addClass('glyphicon-chevron-right');
  } else {
    element.removeClass('glyphicon-chevron-right');
    return element.addClass('glyphicon-chevron-down');
  }
});

formatNumber = function(value, decimalPlaces) {
  var i, j, pattern, ref;
  if (decimalPlaces == null) {
    decimalPlaces = 2;
  }
  pattern = '0';
  if (decimalPlaces) {
    pattern += '.';
    for (i = j = 1, ref = decimalPlaces; 1 <= ref ? j <= ref : j >= ref; i = 1 <= ref ? ++j : --j) {
      pattern += '0';
    }
  }
  return numeral(value).format(pattern);
};
