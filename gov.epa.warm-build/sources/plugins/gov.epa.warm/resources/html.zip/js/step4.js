var checkMaterials, initialize;

initialize = function(data) {
  $('.btn-calculate').on('click', function() {
    if (checkMaterials()) {
      return calculate($('input[name=output_unit]:checked').attr('id'));
    }
  });
  setInputs(data);
  return recordInputs();
};

checkMaterials = function() {
  var i, index, j, k, keys, len, len1, len2, material, materials, ref, ref1, subtype, sum, type;
  materials = inputs.materials;
  if (!materials) {
    return false;
  }
  keys = Object.keys(materials);
  ref = ['baseline', 'alternative'];
  for (i = 0, len = ref.length; i < len; i++) {
    type = ref[i];
    sum = 0;
    for (j = 0, len1 = keys.length; j < len1; j++) {
      index = keys[j];
      material = materials[index];
      ref1 = ['source_reduction', 'landfilling', 'recycling', 'combustion', 'composting', 'anaerobic_digestion'];
      for (k = 0, len2 = ref1.length; k < len2; k++) {
        subtype = ref1[k];
        if (material[type + '_' + subtype]) {
          sum += parseFloat(material[type + '_' + subtype]);
        }
      }
    }
    if (sum === 0) {
      $('.modal').modal();
      return false;
    }
  }
  return true;
};
